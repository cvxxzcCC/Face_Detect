from face.keys import *
import requests
from json import JSONDecoder


#创建一个人脸的集合 FaceSet，用于存储人脸标识 face_token。一个 FaceSet 能够存储 1,000 个 face_token。
def create_faceset(outer_id):
    http_url ="https://api-cn.faceplusplus.com/facepp/v3/faceset/create"
    data = {"api_key": public_key ,
            "api_secret": secret_key,
            "display_name":outer_id,
            "outer_id" :str(outer_id),
            "force_merge": 1 }
    #接收数据
    response = requests.post(http_url, data=data)
    req_con = response.content.decode('utf-8')
    req_dict = JSONDecoder().decode(req_con)
    return req_dict


#获取某一 API Key 下的 FaceSet 列表及其 faceset_token、outer_id、display_name 和 tags 等信息。
def getdetail_faceset(outer_id):
    http_url = "https://api-cn.faceplusplus.com/facepp/v3/faceset/getdetail"
    data = {"api_key": public_key,
            "api_secret": secret_key,
            "outer_id": str(outer_id)}
    #接收数据
    response = requests.post(http_url, data=data)
    req_con = response.content.decode('utf-8')
    req_dict = JSONDecoder().decode(req_con)

    if 'error_message' in req_dict:
        return 0
    else:
        return req_dict
