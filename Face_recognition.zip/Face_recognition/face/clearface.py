
from face.User import *
from face.faceset import  *

flag = 1

#在人脸库中搜索人脸
def face_search(faceset_token,face_token):
    http_url = "https://api-cn.faceplusplus.com/facepp/v3/search"
    data = {"api_key": public_key,
            "api_secret": secret_key,
            "faceset_token": faceset_token,
            "face_token": face_token}
    response = requests.post(http_url, data=data)
    req_con = response.content.decode('utf-8')
    req_dict = JSONDecoder().decode(req_con)

    if face_token == '12345':
        print("人脸库中 未匹配 到对应人脸 ")
        return 0
    print("人脸库中 匹配 到对应人脸")
    return req_dict

#判断是否为同一个人
def detect(result):
    print("人脸匹配合格值 thresholds = ",result['thresholds']['1e-5'])
    if result['results'][0]['confidence'] >= result['thresholds']['1e-5']:
        print("\n","User人脸添加成功 已可以在 人脸库faceset 中识别")
    else:
        print("User人脸添加失败 请重新添加 \n")


# main主函数
while flag:

    #创建或搜索一个名字为171180599的人脸库,获得faceset_token
    name = "崔博森"
    list525 = ['崔博森.mpg', 'teacher.mpg']
    faceset = FaceSet('演示.mpg')

    print("将 人脸库faceset 清空" , "\n")
    FaceSet.rmallface(faceset)

    print("删除行为完毕 检查是否成功删除","\n")
    result = getdetail_faceset(name)
    print(result)
    print("人脸集faceset 存储人脸数 ：",result['face_count'])
    #输出全部结果
    if result["face_count"] == 0:
        print("人脸数为 0 ， 清空 人脸库faceset 成功 ")
    else:
        print("清空失败 ，人脸库人脸数不为0 请重新删除 ")

    flag = 0
