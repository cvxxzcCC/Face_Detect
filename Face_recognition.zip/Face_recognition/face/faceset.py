from face.keys import *
import requests
from json import JSONDecoder
import cv2
import base64
import time
from face.test import  *


#人脸集类
class FaceSet():
    #初始化人脸集，若已存在则获取其face_token，若不存在则创建之
    def __init__(self,outer_id):
        #函数在test中def
        req_dict = getdetail_faceset(outer_id)
        # print(req_dict)
        # display_name = req_dict['display_name']
        # print(display_name)

        #先查是否存在，若存在，则将其添加进去
        #存在人脸库faceset
        if req_dict != 0:
            print("已存在人脸集合:", outer_id, " 可以新信息加入 人脸库faceset ","\n")
            self.faceset_token = req_dict["faceset_token"]
            # print(self.faceset_token)
            self.outer_id = str(outer_id)
            req_dict = getdetail_faceset(outer_id)
            print("当前 人脸库faceset 内容如下：\n", req_dict)
            print("当前 人脸库faceset 中人脸数量为：", req_dict['face_count'], "\n")


        #不存在人脸库faceset
        else:
            print("未发现该人脸库，现创建新的人脸集合：", outer_id)
            self.faceset_token = create_faceset(outer_id)["faceset_token"]
            self.outer_id = str(outer_id)
            req_dict = getdetail_faceset(outer_id)
            print("创建成功")
            print("当前 人脸库faceset 内容如下：\n", req_dict)
            print("当前 人脸库faceset 中人脸数量为：", req_dict['face_count'], "\n")



    #往人脸集中添加人脸
    def addface(self,face_token):
        http_url = "https://api-cn.faceplusplus.com/facepp/v3/faceset/addface"
        data = {"api_key": public_key,
                "api_secret": secret_key,
                "faceset_token": self.faceset_token,
                "face_tokens": face_token}
        #接收数据
        response = requests.post(http_url, data=data)
        req_con = response.content.decode('utf-8')
        req_dict = JSONDecoder().decode(req_con)

        print("已成功将人脸加入到人脸库中\n")
        print("现在 人脸库faceset 内容如下：\n", req_dict)
        print("现在 人脸库faceset 中人脸数量为：", req_dict['face_count'], "\n")


    #从人脸集中删除人脸
    def rmface(self,face_token):
        http_url = "https://api-cn.faceplusplus.com/facepp/v3/faceset/removeface"
        data = {"api_key": public_key,
                "api_secret": secret_key,
                "faceset_token": self.faceset_token,
                "face_tokens": face_token}
        #接收数据
        response = requests.post(http_url, data=data)
        req_con = response.content.decode('utf-8')
        req_dict = JSONDecoder().decode(req_con)
        if req_dict.get("face_removed",0) == 0:
            print("要删除的人脸不在人脸集中 或者 人脸集合本身为空")

    #删除所有人脸
    def rmallface(self):
        self.rmface("RemoveAllFaceTokens")