from face.keys import *
import requests
from json import JSONDecoder
import cv2
import base64
from face.test import  *
from face.User import *
from face.faceset import  *
import datetime
import xlwt
import xlrd
import threading
import device
import time


#在人脸库中搜索人脸
def face_search(faceset_token,face_token):
    http_url = "https://api-cn.faceplusplus.com/facepp/v3/search"
    data = {"api_key": public_key,
            "api_secret": secret_key,
            "faceset_token": faceset_token,
            "face_token": face_token}
    response = requests.post(http_url, data=data)
    req_con = response.content.decode('utf-8')
    req_dict = JSONDecoder().decode(req_con)

    if face_token == '12345':
        print("人脸库中 未匹配 到对应人脸  \n")
        return 0
    print("人脸库中 匹配 到对应人脸 \n")
    return req_dict

#判断是否为同一个人
def detect(result):
    print(" 人脸匹配合格值 thresholds = ",result['thresholds']['1e-5'])
    if result['results'][0]['confidence'] >= result['thresholds']['1e-5']:
        print("\n","检测结果：是同一个人")
    else:
        print("\n","检测结果：不是同一个人 ")

# 人脸识别主函数 是原来的 API 模块
def findface():
    # 人脸识别API模块

    # 将画面转化为64位
    retval, buffer = cv2.imencode('.jpg', frame)
    pic_str = base64.b64encode(buffer)
    pic_str = pic_str.decode()
    print("摄像头画面转换为64位：", pic_str, "\n")

    #提取图片中的信息，对应用户，获得user.token
    user = User(pic_str)

    #创建或搜索一个名字为171180599的人脸库,获得faceset_token
    #此处name在 应为 列表
    # # 遍历 所有
    # name = "teacher.mpg"
    name = '演示.mpg'
    faceset = FaceSet(name)

    #第一个参数是人脸库 第二个参数是人脸 ,搜索人脸
    result = face_search(faceset.faceset_token , user.token)
    #输出全部结果
    print("现在测试是否可以在 人脸库faceset 中识别人脸")

    #输出结果中的“匹配度”
    if result != 0:
        print("人脸识别测试返回数据如下：", result)
        print("测试基本指标如下:\n", "人脸匹配值 confidence = ", result['results'][0]['confidence'])
        # 判断是否是同一个人
        detect(result)
    else:
        print("搜索不到人脸 人脸不存在，匹配度不符合要求\n ")
        print("请重新拍摄照片！")



    #判断是不是都写满了ok 是的话flag = 0



    #flag == 1 的话，先判断是否是1，若不是将写在excel表格内部，写入1
    #flag == 0 的话，写入 no



    #等待5秒再运动
    #正式场合为30秒

    # name flag
    # time.sleep(5)

# 程序循环flag
flag = 1
# 时间计数器
times = 1

# 计时功能------------------------------------------------------------------------输入时间 all_time
hour = 0
minute = 4
second = 30
all_time = (hour * 3600 + minute * 60 + second)

# main主函数 摄像头 + 人脸识别
while flag:

    time_start = time.time()

    # 摄像头模块

    # 参数为0，则打开笔记本内置摄像头；参数是视频文件路径，如"...test/avi"
    # 若参数为0 打开摄像头 按照正常帧数读取
    # 若参数为视频 则会加快速度迅速运行 节省了时间？？
    # ----------------------------------------------------------------------------PPT 更改为 演示.mpg 放入目录
    # cap = cv2.VideoCapture('演示.mpg')
    cap = cv2.VideoCapture(0)
    # cap = cv2.VideoCapture(0)

    # cap.read()按帧读取视频，ret,frame是两个返回值。
    # ret是布尔值（判断是否取到帧数），frame是读取图像,numpy.ndarray类型
    while cap.isOpened():
        ret,frame = cap.read()
        if not ret:
            break

        # 打开窗口显示画面
        cv2.imshow('frame', frame)

        # 帧数截点 是程序循环运行的 周期T
        time_flag = 50
        if (times % time_flag == 1):
            cv2.imwrite('时刻捕捉.png', frame)
            # 人脸识别 API 模块
            flag = findface()
            times = 1

        time_end = time.time()
        real_time = time_end - time_start

        times = times + 1


        # 键盘输入。
        # cv2.waitKey()参数为1，延时1ms；
        # 参数为0，只显示当前帧数，暂停；
        # 参数过大，感觉到卡顿;
        # 同时作为程序退出的条件
        if cv2.waitKey(1) & ( 0xFF == ord('q') or flag == 0 or real_time >= all_time):
            break
#--------------------------------------------------------------------------

cap.release()
cv2.destroyAllWindows()