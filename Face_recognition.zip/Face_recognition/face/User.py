from face.keys import *
import requests
from json import JSONDecoder
import cv2
import base64
import time
from face.test import  *


#用户类
class User():
    #人脸对象初始化，赋地址
    def __init__(self,address):
        self.address = address
        self.create_face()
        self.flag = 0


    #人脸识别，获得FACE_TOKEN
    #实际上是对应API文档的detect
    #提取人脸关键信息
    def create_face(self):
        http_url = "https://api-cn.faceplusplus.com/facepp/v3/detect"
        data = {"api_key": public_key,
                "api_secret": secret_key,
                "return_attributes": "facequality",
                "image_base64": self.address
                }
        files = {"image_base64": self.address}
        #接收数据
        response = requests.post(http_url, data=data, files=files)
        req_con = response.content.decode('utf-8')
        req_dict = JSONDecoder().decode(req_con)


        print("API 检测 User 所有结果信息为：\n",req_dict)

        # 此处应 严紫轩 要求 ，打印token 放在此处不会影响后面的代码
        if len(req_dict["faces"]):
            # if req_dict["faces"][0]["attributes"]["facequality"]["value"] > req_dict["faces"][0]["attributes"]["facequality"]["threshold"]:
            for i in range(len(req_dict['faces'])):
                self.token = req_dict["faces"][i]["face_token"]
                print("API 检测 User 结果中 face_token为：\n", req_dict["faces"][i]["face_token"], "\n")
        else:
            print("清晰度不够，请重新拍摄！\n")
            self.token = '12345'

        #将token赋值 但是目前只能将token赋值一个数值 需要将token改造成列表
        if len(req_dict["faces"]):
           # if req_dict["faces"][0]["attributes"]["facequality"]["value"] > req_dict["faces"][0]["attributes"]["facequality"]["threshold"]:
                self.token = req_dict["faces"][0]["face_token"]
                print("API 检测 User 结果中 face_token为：\n", req_dict["faces"][0]["face_token"], "\n")
        else:
            print("清晰度不够，请重新拍摄！\n")
            self.token = '12345'
