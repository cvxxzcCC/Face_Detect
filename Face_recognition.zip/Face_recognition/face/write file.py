

import  xlwt
import  xlrd
import  os
from datetime import date,datetime

name=1
flag =0


#
#





workbook = xlrd.open_workbook('test.xlsx')

#输出所有sheet名字
print(workbook.sheet_names())

#根据下表获取名称
sheet2_name = workbook.sheet_names()[1]
print(sheet2_name)

#获取sheet中的col和row
sheet2 = workbook.sheet_by_index(1)
print(sheet2_name,sheet2.nrows,sheet2.ncols)

#获取sheet名称 任一row col的数值
sheet2 = workbook.sheet_by_name('cc')
rows = sheet2.row_values(0)
cols = sheet2.col_values(0)
print(rows)
print(cols)

#获取指定单元格的内容&数据类型
print(sheet2.cell(0,0).ctype)
print("a")
print(sheet2.cell_value(0,0))



# Data_sheet = workbook.sheets()[0]
# CdfData_sheet = workbook.sheet_by_index(1)
# Charts_sheet = workbook.sheet_by_name(u'Charts')
#
# print(
#     Data_sheet,     Data_sheet.nrows,   Data_sheet.ncols,\
#     CdfData_sheet.name, CdfData_sheet.nrows,    CdfData_sheet.ncols,\
#     Charts_sheet.name,  CdfData_sheet.nrows,    Charts_sheet.ncols
# )