
from face.User import *
from face.faceset import  *


#在人脸库中搜索人脸
def face_search(faceset_token,face_token):
    http_url = "https://api-cn.faceplusplus.com/facepp/v3/search"
    data = {"api_key": public_key,
            "api_secret": secret_key,
            "faceset_token": faceset_token,
            "face_token": face_token}
    response = requests.post(http_url, data=data)
    req_con = response.content.decode('utf-8')
    req_dict = JSONDecoder().decode(req_con)

    if face_token == '12345':
        print("人脸库中 未匹配 到对应人脸 ")
        return 0
    print("人脸库中 匹配 到对应人脸")
    return req_dict

#判断是否为同一个人
def detect(result):
    print("人脸匹配合格值 thresholds = ",result['thresholds']['1e-5'])
    if result['results'][0]['confidence'] >= result['thresholds']['1e-5']:
        print("\n","User人脸添加成功 已可以在 人脸库faceset 中识别")
        return 1
    else:
        print("User人脸添加失败 请重新添加 \n")
        return 0





# API 添加人脸 主函数
def addface():

    # 人脸识别API模块

    # 将画面转化为64位
    retval, buffer = cv2.imencode('.jpg', frame)
    pic_str = base64.b64encode(buffer)
    pic_str = pic_str.decode()
    print("摄像头画面转换为64位：", pic_str, "\n")

    #提取图片中的信息，对应用户，获得user.token
    idname = "cc"
    user = User(pic_str)

    #创建或搜索一个名字为171180599的人脸库,获得faceset_token
    # name = input()
    # 此处name为字符串-------------------------------------------------------------------------人脸集合FaceSet
    name = "171180599"
    faceset = FaceSet(name)

    #将用户User信息储存在人脸库中
    faceset.addface(user.token)

    #第一个参数是人脸库 第二个参数是人脸 ,搜索人脸
    result = face_search(faceset.faceset_token,user.token)
    #输出全部结果
    print("现在测试是否可以在 人脸库faceset 中识别人脸")

    #输出结果中的“匹配度”
    if result != 0:
        print("人脸识别测试返回数据如下：",result)
        print("测试基本指标如下:\n" , "人脸匹配值 confidence = " , result['results'][0]['confidence'])
        # 判断是否是同一个人
        return detect(result)
    else:
        print("搜索不到人脸 人脸不存在，匹配度不符合要求\n ")
        print("请重新拍摄照片！")
        return 0


# 程序循环flag
flag = 1
# 时间计数器
time = 1
# 人脸数量计数器
number = 0
# 当人脸数量达到指定要求了 就停止
open = 1

# main主函数
while flag:

    # 摄像头模块
    timef = 300

    # 参数为0，则打开笔记本内置摄像头；参数是视频文件路径，如"...test/avi"
    # 若参数为0 打开摄像头 按照正常帧数读取
    # 若参数为视频 则会加快速度迅速运行 节省了时间？？
    # 视频方式亦可加入人脸 20s左右的 头部运动 速度不要过快
    name = 0
    cap = cv2.VideoCapture(0)


    # cap.read()按帧读取视频，ret,frame是两个返回值。
    # ret是布尔值（判断是否取到帧数），frame是读取图像,numpy.ndarray类型
    while cap.isOpened():
        ret,frame = cap.read()
        if not ret:
            break

        # 打开窗口显示画面
        cv2.imshow('frame', frame)

        # 帧数截点 是程序循环运行
        time_flag = 50
        if (time % time_flag == 1):
            cv2.imwrite('a.png', frame)

            # 人脸识别 API 模块
            if addface() == 1:
                number = number + 1

            # 成功增加人脸到一定数量后 结束 add
            if number == 20 :
                open = 0

        time = time + 1


        # 键盘输入。
        # cv2.waitKey()参数为1，延时1ms；
        # 参数为0，只显示当前帧数，暂停；
        # 参数过大，感觉到卡顿;
        if cv2.waitKey(1) & (0xFF == ord('q') or open == 0) :
            flag = 0
            break
#--------------------------------------------------------------------------

cap.release()
cv2.destroyAllWindows()