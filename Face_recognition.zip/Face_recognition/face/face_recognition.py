from face.keys import *
import requests
from json import JSONDecoder

#图片路径
filepath1 = r'C:\Users\cvxxzcCC\Desktop\Mathew_3.jpg'


def face_recognition(filepath):
    http_url = "https://api-cn.faceplusplus.com/facepp/v3/detect"
    data = {"api_key": public_key , "api_secret": secret_key , "return_attributes":"facequality"}
    files = {"image_file": open(filepath, "rb")}
    response = requests.post(http_url, data=data, files=files)
    req_con = response.content.decode('utf-8')
    req_dict = JSONDecoder().decode(req_con)
    return req_dict
