# -*- coding:utf8 -*-

import os

def get_filename():
    list = []
    path=r'C:\Users\cvxxzcCC\Desktop\Python\Face_recognition\vedio'
    filenames = os.listdir(path)
    for filename in filenames:
        print( os.path.splitext(filename))
        if os.path.splitext(filename)[1] ==  '.mpg':
            list.append(filename)
    return list

print(get_filename())




# -*- coding:utf8 -*-


